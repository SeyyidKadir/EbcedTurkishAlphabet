﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmEsmaAra : Form
    {
        public FrmEsmaAra()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        List<string[]> liste;
        private void btnHesapla_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtYazi.Text))
            {
                lbSonuc.Items.Clear();
                if (checkBox1.Checked == true)
                {
                    liste = eat.EsmaAlGenis(txtYazi.Text);
                    if (liste.Count > 0)
                    {
                        foreach (string[] sonuc in liste)
                        {
                            lbSonuc.Items.Add(sonuc[0]);
                        }
                    }
                    else
                    {
                        lbSonuc.Items.Add("Esma bulunamadı mübarek bir şeyleri yanlış yapıyorsun :)");
                    }
                }
                else
                {
                    liste = eat.EsmaAlNormal(txtYazi.Text);
                    if (liste.Count > 0)
                    {
                        foreach (string[] sonuc in liste)
                        {
                            lbSonuc.Items.Add(sonuc[0]);
                        }
                    }
                    else
                    {
                        lbSonuc.Items.Add("Esma bulunamadı mübarek bir de \"detaylı arama\" yap :)");
                    }
                }
            }
            else
            {
                lbSonuc.Items.Clear();
                lbSonuc.Items.Add("Boş geçme mübarek :)");
            }
        }

        private void FrmEsmaAra_Load(object sender, EventArgs e)
        {
            eat.Init();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (lbSonuc.Items.Count > 0)
            {
                FrmEsmaDetay detay = new FrmEsmaDetay();
                string[] secilen = liste[lbSonuc.SelectedIndex];
                detay.isim = secilen[0];
                detay.aciklama = secilen[2];
                detay.resimyolu = "isimlerPNG/" + secilen[1];
                detay.Show();
            }
            else
            {
                lbSonuc.Items.Clear();
                lbSonuc.Items.Add("Arama yap mübarek olur mu bu şimdi :)");
            }
        }
    }
}
