﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmEbcedHarfsayisiBul : Form
    {
        public FrmEbcedHarfsayisiBul()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        private void btnHesapla_Click(object sender, EventArgs e)
        {
            if (nudsayi.Value > 0)
            {
                List<double> sonuc = eat.GetEbcedToCharactersSome((int)nudsayi.Value);
                if (sonuc.Count > 0)
                {
                    txtSonuc.Text = sonuc[0].ToString() + " - " + sonuc[1].ToString();
                }
                else
                {
                    txtSonuc.Text = "Yanlış şeyler oldu mübarek bir veri'yi kontrol et";
                }
            }
            else
            {
                txtSonuc.Text = "Sayı gir mübarek :)";
            }
        }

        private void FrmEbcedHarfsayisiBul_Load(object sender, EventArgs e)
        {
            eat.Init();
        }
    }
}
