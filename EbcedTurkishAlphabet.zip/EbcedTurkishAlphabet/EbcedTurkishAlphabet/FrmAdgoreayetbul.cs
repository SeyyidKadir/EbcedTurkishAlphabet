﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmAdgoreayetbul : Form
    {
        public FrmAdgoreayetbul()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        private void btnBul_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtYazi.Text))
            {
                List<int> sonuc1 = eat.GiveMeAyatMyName(txtYazi.Text);
                if (sonuc1.Count > 0)
                {
                    try
                    {
                        txtHarf1.Text = sonuc1[0].ToString();
                        txtAyet1.Text = sonuc1[1].ToString();
                        txtSure1.Text = sonuc1[2].ToString();
                    }
                    catch
                    { 
                      
                    }
                }
                else
                {
                    MessageBox.Show("Bir şeyleri yanlış yaptın mübarek :)");
                }
            }
            else
            {
                MessageBox.Show("Alanı doldur mübarek :)");
            }
        }

        private void FrmAdgoreayetbul_Load(object sender, EventArgs e)
        {
            eat.Init();
        }

        private void btnDetay_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSure1.Text))
            {
                FrmSureIsimDetay fsid = new FrmSureIsimDetay();
                string sureadi = eat.KuranSureler[int.Parse(txtSure1.Text)];
                string surekarsiligi = eat.KuranSureTurkceIsimleri[sureadi];
                fsid.sureadi1 = sureadi;
                fsid.surekarsilik = surekarsiligi;
                fsid.ShowDialog();
            }
            else
            {
                MessageBox.Show("Aramadın ki mübarek :)");
            }
        }
    }
}
