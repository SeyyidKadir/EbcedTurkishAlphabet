﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmSureIsimDetay : Form
    {
        public FrmSureIsimDetay()
        {
            InitializeComponent();
        }
        public string sureadi1 = "";
        public string surekarsilik = "";
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void FrmSureIsimDetay_Load(object sender, EventArgs e)
        {
            lblsurebaslik.Text = sureadi1;
            txtAnlam.Text = surekarsilik;
        }
    }
}
