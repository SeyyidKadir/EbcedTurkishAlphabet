﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmEvradEskapHesapla : Form
    {
        public FrmEvradEskapHesapla()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        private void btnHesapla_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtYazi.Text))
            {
                int sonuc = eat.EvradEskat(txtYazi.Text);
                if (sonuc > 0)
                {
                    txtSonuc.Text = sonuc.ToString();
                }
                else
                {
                    txtSonuc.Text = "Doğru veri girilmedi mübarek :)";
                }
            }
            else
            {
                txtSonuc.Text = "Mübarek Boş Geçme :)";
            }
        }

        private void FrmEvradEskapHesapla_Load(object sender, EventArgs e)
        {
            eat.Init();
        }
    }
}
