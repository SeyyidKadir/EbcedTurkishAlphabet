﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class frmVefkHazirla : Form
    {
        public frmVefkHazirla()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        List<string[]> liste;
        private void frmVefkHazirla_Load(object sender, EventArgs e)
        {
            eat.Init();
            liste = eat.AllahIsimleri;
            foreach (string[] isimler in liste)
            {
                lbEsmalar.Items.Add(isimler[0]);
            }
        }

        private void btnVefkHazirla_Click(object sender, EventArgs e)
        {
            if (lbEsmalar.SelectedItem != null)
            {
                FrmVefkGoster goster = new FrmVefkGoster();
                goster.bmpVefk = eat.EsmaYaGoreVefk7(liste[lbEsmalar.SelectedIndex]);
                goster.ShowDialog();
            }
            else
            {
                MessageBox.Show("Bir esma seç mübarek :)");
            }
        }
    }
}
