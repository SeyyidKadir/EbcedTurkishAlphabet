﻿namespace EbcedTurkishAlphabet
{
    partial class FrmSureIsimDetay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblsurebaslik = new System.Windows.Forms.Label();
            this.txtAnlam = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblsurebaslik
            // 
            this.lblsurebaslik.AutoSize = true;
            this.lblsurebaslik.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblsurebaslik.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblsurebaslik.Location = new System.Drawing.Point(80, 15);
            this.lblsurebaslik.Name = "lblsurebaslik";
            this.lblsurebaslik.Size = new System.Drawing.Size(0, 25);
            this.lblsurebaslik.TabIndex = 0;
            // 
            // txtAnlam
            // 
            this.txtAnlam.BackColor = System.Drawing.Color.DarkGreen;
            this.txtAnlam.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtAnlam.ForeColor = System.Drawing.Color.White;
            this.txtAnlam.Location = new System.Drawing.Point(1, 43);
            this.txtAnlam.Multiline = true;
            this.txtAnlam.Name = "txtAnlam";
            this.txtAnlam.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAnlam.Size = new System.Drawing.Size(330, 126);
            this.txtAnlam.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(206, 176);
            this.button1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 32);
            this.button1.TabIndex = 2;
            this.button1.Text = "Tamam";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmSureIsimDetay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(341, 216);
            this.Controls.Add(this.txtAnlam);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblsurebaslik);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSureIsimDetay";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmSureIsimDetay_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblsurebaslik;
        private System.Windows.Forms.TextBox txtAnlam;
        private System.Windows.Forms.Button button1;
    }
}