﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmOzelNumaraHesapla : Form
    {
        public FrmOzelNumaraHesapla()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        private void FrmOzelNumaraHesapla_Load(object sender, EventArgs e)
        {
            eat.Init();
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtYazi.Text) && nudsayi.Value > 0)
            {
                int sonuc = eat.FindAnyNumberStrange(txtYazi.Text, nudsayi.Value.ToString());
                if (sonuc > 0)
                {
                    txtSonuc.Text = sonuc.ToString();
                }
                else
                {
                    txtSonuc.Text = "Yanlış bir şeyler yaptın mübarek :)";
                }
            }
            else
            {
                txtSonuc.Text = "Alanları doldur mübarek :)";
            }
        }
    }
}
