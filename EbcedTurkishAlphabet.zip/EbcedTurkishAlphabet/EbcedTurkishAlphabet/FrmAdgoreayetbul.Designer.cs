﻿namespace EbcedTurkishAlphabet
{
    partial class FrmAdgoreayetbul
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAdgoreayetbul));
            this.btnBul = new System.Windows.Forms.Button();
            this.txtHarf1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtYazi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAyet1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSure1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnDetay = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBul
            // 
            this.btnBul.BackColor = System.Drawing.Color.DarkGreen;
            this.btnBul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBul.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBul.ForeColor = System.Drawing.Color.White;
            this.btnBul.Location = new System.Drawing.Point(364, 138);
            this.btnBul.Name = "btnBul";
            this.btnBul.Size = new System.Drawing.Size(84, 37);
            this.btnBul.TabIndex = 14;
            this.btnBul.Text = "Bul";
            this.btnBul.UseVisualStyleBackColor = false;
            this.btnBul.Click += new System.EventHandler(this.btnBul_Click);
            // 
            // txtHarf1
            // 
            this.txtHarf1.BackColor = System.Drawing.Color.DarkGreen;
            this.txtHarf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtHarf1.ForeColor = System.Drawing.Color.White;
            this.txtHarf1.Location = new System.Drawing.Point(117, 50);
            this.txtHarf1.Name = "txtHarf1";
            this.txtHarf1.ReadOnly = true;
            this.txtHarf1.Size = new System.Drawing.Size(421, 24);
            this.txtHarf1.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.DarkGreen;
            this.label2.Location = new System.Drawing.Point(15, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "Kaçıncı harf :";
            // 
            // txtYazi
            // 
            this.txtYazi.BackColor = System.Drawing.Color.DarkGreen;
            this.txtYazi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtYazi.ForeColor = System.Drawing.Color.White;
            this.txtYazi.Location = new System.Drawing.Point(117, 18);
            this.txtYazi.Name = "txtYazi";
            this.txtYazi.Size = new System.Drawing.Size(421, 24);
            this.txtYazi.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(69, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Yazı:";
            // 
            // txtAyet1
            // 
            this.txtAyet1.BackColor = System.Drawing.Color.DarkGreen;
            this.txtAyet1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtAyet1.ForeColor = System.Drawing.Color.White;
            this.txtAyet1.Location = new System.Drawing.Point(117, 80);
            this.txtAyet1.Name = "txtAyet1";
            this.txtAyet1.ReadOnly = true;
            this.txtAyet1.Size = new System.Drawing.Size(421, 24);
            this.txtAyet1.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.DarkGreen;
            this.label3.Location = new System.Drawing.Point(15, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Kaçıncı ayet :";
            // 
            // txtSure1
            // 
            this.txtSure1.BackColor = System.Drawing.Color.DarkGreen;
            this.txtSure1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSure1.ForeColor = System.Drawing.Color.White;
            this.txtSure1.Location = new System.Drawing.Point(117, 110);
            this.txtSure1.Name = "txtSure1";
            this.txtSure1.ReadOnly = true;
            this.txtSure1.Size = new System.Drawing.Size(421, 24);
            this.txtSure1.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.DarkGreen;
            this.label4.Location = new System.Drawing.Point(15, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 16);
            this.label4.TabIndex = 17;
            this.label4.Text = "Kaçıncı süre :";
            // 
            // btnDetay
            // 
            this.btnDetay.BackColor = System.Drawing.Color.DarkGreen;
            this.btnDetay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDetay.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDetay.ForeColor = System.Drawing.Color.White;
            this.btnDetay.Location = new System.Drawing.Point(454, 138);
            this.btnDetay.Name = "btnDetay";
            this.btnDetay.Size = new System.Drawing.Size(84, 37);
            this.btnDetay.TabIndex = 19;
            this.btnDetay.Text = "Detay";
            this.btnDetay.UseVisualStyleBackColor = false;
            this.btnDetay.Click += new System.EventHandler(this.btnDetay_Click);
            // 
            // FrmAdgoreayetbul
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 187);
            this.Controls.Add(this.btnDetay);
            this.Controls.Add(this.txtSure1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAyet1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnBul);
            this.Controls.Add(this.txtHarf1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtYazi);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(559, 225);
            this.MinimumSize = new System.Drawing.Size(559, 225);
            this.Name = "FrmAdgoreayetbul";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "İsime Karşılık Ayet Bul";
            this.Load += new System.EventHandler(this.FrmAdgoreayetbul_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBul;
        private System.Windows.Forms.TextBox txtHarf1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtYazi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAyet1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSure1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDetay;
    }
}