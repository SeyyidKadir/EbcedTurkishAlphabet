﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void FrmMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmEbcedHesapla hesapla = new FrmEbcedHesapla();
            hesapla.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmCokluEbcedHesapla hesapla2 = new frmCokluEbcedHesapla();
            hesapla2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmEsmaAra ara = new FrmEsmaAra();
            ara.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmEvradEskapHesapla hesapla22 = new FrmEvradEskapHesapla();
            hesapla22.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FrmOzelNumaraHesapla hesapla23 = new FrmOzelNumaraHesapla();
            hesapla23.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmAdgoreayetbul ayetbul = new FrmAdgoreayetbul();
            ayetbul.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            frmVefkHazirla hazirla = new frmVefkHazirla();
            hazirla.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            FrmEbcedHarfsayisiBul bul = new FrmEbcedHarfsayisiBul();
            bul.Show();
        }
    }
}
