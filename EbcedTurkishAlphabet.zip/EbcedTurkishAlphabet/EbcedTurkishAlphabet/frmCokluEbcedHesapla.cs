﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class frmCokluEbcedHesapla : Form
    {
        public frmCokluEbcedHesapla()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        private void BtnEkle_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtYazi.Text))
            {
                if (!lbYazilar.Items.Contains(txtYazi.Text))
                {
                    lbYazilar.Items.Add(txtYazi.Text);
                }
                else
                {
                    txtSonuc.Text = "Aynı veri'yi ekleme mübarek :)";
                }
            }
            else
            {
                txtSonuc.Text = "Boş geçme mübarek :)";
            }
        }

        private void BtnTemizle_Click(object sender, EventArgs e)
        {
            if (lbYazilar.Items.Count > 0)
            {
                if (MessageBox.Show("Eğer yanlışlıkla bastıysan hepsi silinecek muhterem :)", "İçerik temizlensin mi ?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    lbYazilar.Items.Clear();
                }
            }
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            if (lbYazilar.Items.Count > 0)
            {
                List<string> input1 = new List<string>();
                foreach (string items in lbYazilar.Items)
                {
                    input1.Add(items);
                }
                int result = eat.GetManyNameEbcedSum(input1);
                txtSonuc.Text = result.ToString();
            }
            else
            {
                txtSonuc.Text = "Hesaplamak için veri gir mübarek :)";
            }
        }

        private void frmCokluEbcedHesapla_Load(object sender, EventArgs e)
        {
            eat.Init();
        }
    }
}
