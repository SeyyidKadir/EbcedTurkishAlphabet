﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmEsmaDetay : Form
    {
        public FrmEsmaDetay()
        {
            InitializeComponent();
        }
        public string resimyolu;
        public string isim;
        public string aciklama;
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void FrmEsmaDetay_Load(object sender, EventArgs e)
        {
            PbArapca.ImageLocation = resimyolu;
            lblAd.Text = isim;
            txtAnlam.Text = aciklama;
        }
    }
}
