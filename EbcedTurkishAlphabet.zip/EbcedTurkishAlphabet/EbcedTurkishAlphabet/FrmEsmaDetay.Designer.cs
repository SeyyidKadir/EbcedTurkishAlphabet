﻿namespace EbcedTurkishAlphabet
{
    partial class FrmEsmaDetay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtAnlam = new System.Windows.Forms.TextBox();
            this.PbArapca = new System.Windows.Forms.PictureBox();
            this.lblAd = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PbArapca)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(231, 370);
            this.button1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Tamam";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtAnlam
            // 
            this.txtAnlam.BackColor = System.Drawing.Color.DarkGreen;
            this.txtAnlam.ForeColor = System.Drawing.Color.White;
            this.txtAnlam.Location = new System.Drawing.Point(26, 237);
            this.txtAnlam.Multiline = true;
            this.txtAnlam.Name = "txtAnlam";
            this.txtAnlam.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAnlam.Size = new System.Drawing.Size(330, 126);
            this.txtAnlam.TabIndex = 1;
            // 
            // PbArapca
            // 
            this.PbArapca.Location = new System.Drawing.Point(26, 51);
            this.PbArapca.Name = "PbArapca";
            this.PbArapca.Size = new System.Drawing.Size(330, 180);
            this.PbArapca.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PbArapca.TabIndex = 2;
            this.PbArapca.TabStop = false;
            // 
            // lblAd
            // 
            this.lblAd.AutoSize = true;
            this.lblAd.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblAd.Location = new System.Drawing.Point(23, 19);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(0, 18);
            this.lblAd.TabIndex = 3;
            // 
            // FrmEsmaDetay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(389, 428);
            this.Controls.Add(this.lblAd);
            this.Controls.Add(this.PbArapca);
            this.Controls.Add(this.txtAnlam);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximumSize = new System.Drawing.Size(389, 428);
            this.MinimumSize = new System.Drawing.Size(389, 428);
            this.Name = "FrmEsmaDetay";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.FrmEsmaDetay_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PbArapca)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtAnlam;
        private System.Windows.Forms.PictureBox PbArapca;
        private System.Windows.Forms.Label lblAd;
    }
}