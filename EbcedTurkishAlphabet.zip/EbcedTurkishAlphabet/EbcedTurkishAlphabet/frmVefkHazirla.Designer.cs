﻿namespace EbcedTurkishAlphabet
{
    partial class frmVefkHazirla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVefkHazirla));
            this.label1 = new System.Windows.Forms.Label();
            this.lbEsmalar = new System.Windows.Forms.ListBox();
            this.btnVefkHazirla = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Esmalar :";
            // 
            // lbEsmalar
            // 
            this.lbEsmalar.BackColor = System.Drawing.Color.DarkGreen;
            this.lbEsmalar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbEsmalar.ForeColor = System.Drawing.Color.White;
            this.lbEsmalar.FormattingEnabled = true;
            this.lbEsmalar.ItemHeight = 20;
            this.lbEsmalar.Location = new System.Drawing.Point(12, 42);
            this.lbEsmalar.Name = "lbEsmalar";
            this.lbEsmalar.Size = new System.Drawing.Size(630, 204);
            this.lbEsmalar.TabIndex = 8;
            // 
            // btnVefkHazirla
            // 
            this.btnVefkHazirla.BackColor = System.Drawing.Color.DarkGreen;
            this.btnVefkHazirla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVefkHazirla.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnVefkHazirla.ForeColor = System.Drawing.Color.White;
            this.btnVefkHazirla.Location = new System.Drawing.Point(502, 252);
            this.btnVefkHazirla.Name = "btnVefkHazirla";
            this.btnVefkHazirla.Size = new System.Drawing.Size(139, 68);
            this.btnVefkHazirla.TabIndex = 10;
            this.btnVefkHazirla.Text = "Seçileni Vefk Hazırla";
            this.btnVefkHazirla.UseVisualStyleBackColor = false;
            this.btnVefkHazirla.Click += new System.EventHandler(this.btnVefkHazirla_Click);
            // 
            // frmVefkHazirla
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(653, 337);
            this.Controls.Add(this.btnVefkHazirla);
            this.Controls.Add(this.lbEsmalar);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(669, 375);
            this.MinimumSize = new System.Drawing.Size(669, 375);
            this.Name = "frmVefkHazirla";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vefk Hazırla";
            this.Load += new System.EventHandler(this.frmVefkHazirla_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbEsmalar;
        private System.Windows.Forms.Button btnVefkHazirla;
    }
}