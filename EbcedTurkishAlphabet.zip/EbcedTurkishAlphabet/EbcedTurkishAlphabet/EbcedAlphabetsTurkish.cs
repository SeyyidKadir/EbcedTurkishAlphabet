﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EbcedTurkishAlphabet
{
    class EbcedAlphabetsTurkish
    {
        public Dictionary<char, int> Ekarakterler = new Dictionary<char, int>();
        public const int FAIL = -1;
        public const int NOT_INIT_CALLED = -2;
        public const int SURE = 114;
        public const int AYAT = 6236;
        public List<string[]> AllahIsimleri = new List<string[]>();
        public Dictionary<int, string> KuranSureler = new Dictionary<int, string>();
        public Dictionary<string, string> KuranSureTurkceIsimleri = new Dictionary<string, string>();
        public void Init()
        {
            Ekarakterler.Add('A', 1);
            Ekarakterler.Add('F', 8);
            Ekarakterler.Add('J', 3);
            Ekarakterler.Add('Ö', 7);
            Ekarakterler.Add('U', 7);
            Ekarakterler.Add('B', 2);
            Ekarakterler.Add('G', 8);
            Ekarakterler.Add('K', 4);
            Ekarakterler.Add('P', 2);
            Ekarakterler.Add('Ü', 7);
            Ekarakterler.Add('C', 3);
            Ekarakterler.Add('Ğ', 4);
            Ekarakterler.Add('L', 6);
            Ekarakterler.Add('R', 8);
            Ekarakterler.Add('V', 6);
            Ekarakterler.Add('Ç', 3);
            Ekarakterler.Add('H', 8);
            Ekarakterler.Add('M', 4);
            Ekarakterler.Add('S', 0);
            Ekarakterler.Add('Y', 10);
            Ekarakterler.Add('D', 4);
            Ekarakterler.Add('I', 10);
            Ekarakterler.Add('N', 2);
            Ekarakterler.Add('Ş', 0);
            Ekarakterler.Add('Z', 7);
            Ekarakterler.Add('E', 5);
            Ekarakterler.Add('İ', 10);
            Ekarakterler.Add('O', 7);
            Ekarakterler.Add('T', 4);

            AllahIsimleri.Add(new string[] { "ALLAH", "0.png", "Tüm isim ve sıfatları kendinde toplayan." });
            AllahIsimleri.Add(new string[] { "Rahman", "1.png", "Rahmetiyle muamele eden, esirgeyen." });
            AllahIsimleri.Add(new string[] { "Rahim", "2.png", "Merhamet eden, bağışlayan." });
            AllahIsimleri.Add(new string[] { "Melik", "3.png", "Mülkün gerçek sahibi, mülk ve saltanatı devamlı olan." });
            AllahIsimleri.Add(new string[] { "Kuddus", "4.png", "Her türlü eksiklik ve ayıplardan münezzeh olan." });
            AllahIsimleri.Add(new string[] { "Selam", "5.png", "Kullarını selâmete çıkaran." });
            AllahIsimleri.Add(new string[] { "Mümin", "6.png", "Gönüllerde iman ışığı uyandıran." });
            AllahIsimleri.Add(new string[] { "Muheymin", "7.png", "Gözeten ve koruyan." });
            AllahIsimleri.Add(new string[] { "Aziz", "8.png", "Mağlup edilmesi asla mümkün olmayan." });
            AllahIsimleri.Add(new string[] { "Cebbar", "9.png", "İstediğini mutlak yapan, dilediğine muktedir olan." });
            AllahIsimleri.Add(new string[] { "Mutekebbir", "10.png", "Her şeyde büyüklüğünü gösteren." });
            AllahIsimleri.Add(new string[] { "Halık", "11.png", "Her şeyi yoktan var eden." });
            AllahIsimleri.Add(new string[] { "Bari", "12.png", "Her şeyi uygun bir tarzda ve birbirine uygun yaratan." });
            AllahIsimleri.Add(new string[] { "Musavvir", "13.png", "Her şeye bir şekil ve hususiyet verip tasvir eden." });
            AllahIsimleri.Add(new string[] { "Gaffar", "14.png", "Kullarının günahlarını örten, günahlarını bağışlayan." });
            AllahIsimleri.Add(new string[] { "Kahhar", "15.png", "Her şeye, her istediğini yapacak surette galip ve hakim olan." });
            AllahIsimleri.Add(new string[] { "Vehhab", "16.png", "Çok fazla ihsan eden." });
            AllahIsimleri.Add(new string[] { "Rezzak", "17.png", "Bütün mahlukatın rızkını veren ve ihtiyacını karşılayan." });
            AllahIsimleri.Add(new string[] { "Fettah", "18.png", "Her türlü zorlukları kolaylaştıran, darlıktan kurtaran." });
            AllahIsimleri.Add(new string[] { "Alim", "19.png", "Her şeyi en ince noktasına kadar bilen, ilmi ebedi ve ezeli olan." });
            AllahIsimleri.Add(new string[] { "Kabıd", "20.png", "Dilediğine darlık veren, sıkan, daraltan." });
            AllahIsimleri.Add(new string[] { "Basıt", "21.png", "Dilediğine bolluk veren, açan, genişleten." });
            AllahIsimleri.Add(new string[] { "Hafıd", "22.png", "Yukarıdan aşağıya indiren, alçaltan." });
            AllahIsimleri.Add(new string[] { "Rafi", "23.png", "Yukarı kaldıran, yükselten." });
            AllahIsimleri.Add(new string[] { "Muiz", "24.png", "İzzet verip ağırlayan." });
            AllahIsimleri.Add(new string[] { "Muzil", "25.png", "Zillete düşüren, hor ve hakir eden." });
            AllahIsimleri.Add(new string[] { "Semi", "26.png", "Her şeyi işiten." });
            AllahIsimleri.Add(new string[] { "Basir", "27.png", "Her şeyi gören." });
            AllahIsimleri.Add(new string[] { "Hakem", "28.png", "Her işte hikmet ve adaletle hükmeden." });
            AllahIsimleri.Add(new string[] { "Adl", "29.png", "Son derece adaletli olan." });
            AllahIsimleri.Add(new string[] { "Latif", "30.png", "İşlerin bütün inceliklerini bilen." });
            AllahIsimleri.Add(new string[] { "Habir", "31.png", "Her şeyin iç yüzünden, gizli tarafından haberdar olan." });
            AllahIsimleri.Add(new string[] { "Halim", "32.png", "Yumuşak davranan, hilmi çok olan." });
            AllahIsimleri.Add(new string[] { "Azim", "33.png", "Pek azametli ve büyük olan." });
            AllahIsimleri.Add(new string[] { "Gafur", "34.png", "Çok bağışlayan, magfireti çok olan." });
            AllahIsimleri.Add(new string[] { "Şekur", "35.png", "Kendi rızası için yapılan iyi işleri, ziyadesiyle mükafatlandıran." });
            AllahIsimleri.Add(new string[] { "Aliyy", "36.png", "Çok yüce. Pek yüksek olan." });
            AllahIsimleri.Add(new string[] { "Kebir", "37.png", "Büyüklüğünde hudut olmayan." });
            AllahIsimleri.Add(new string[] { "Hafiz", "38.png", "Yapılan işleri bütün tafsilatıyla, ayrıntılarıyla tutan." });
            AllahIsimleri.Add(new string[] { "Mukit", "39.png", "Yaratılmış her şeyin azığını veren." });
            AllahIsimleri.Add(new string[] { "Hasib", "40.png", "Herkesin hayatı boyunca yaptıklarının hesabını soran." });
            AllahIsimleri.Add(new string[] { "Celil", "41.png", "Azamet sahibi olan, ululuk sahibi olan." });
            AllahIsimleri.Add(new string[] { "Kerim", "42.png", "Çok ikram edici. Keremi ve mağfireti bol olan." });
            AllahIsimleri.Add(new string[] { "Rakib", "43.png", "Bütün varlıklar üzerine gözcü olan." });
            AllahIsimleri.Add(new string[] { "Mucib", "44.png", "Dua edenlerin dualarını kabul eden, isteklerini veren." });
            AllahIsimleri.Add(new string[] { "Vasi", "45.png", "Lütfu bol olan." });
            AllahIsimleri.Add(new string[] { "Hakim", "46.png", "Emirleri, kelamı ve bütün işleri hikmetli olan." });
            AllahIsimleri.Add(new string[] { "Vedud", "47.png", "İyi kullarını seven, sevilmeye ve dostluğa hakkıyla layık olan." });
            AllahIsimleri.Add(new string[] { "Mecid", "48.png", "Şanı çok büyük ve çok yüksek olan." });
            AllahIsimleri.Add(new string[] { "Bais", "49.png", "Ölüleri diriltip kabirlerinden çıkaran." });
            AllahIsimleri.Add(new string[] { "Şehid", "50.png", "Her zaman ve her yerde hazır ve nazır olan." });
            AllahIsimleri.Add(new string[] { "Hakk", "51.png", "Vacib\"ul vücut olan, varlığı hiç değişmeden duran." });
            AllahIsimleri.Add(new string[] { "Vekil", "52.png", "İşlerini kendisine bırakanların işini düzelten ve her şeyin iyisini temin eden." });
            AllahIsimleri.Add(new string[] { "Kaviyy", "53.png", "Pek kuvvetli. Pek güçlü olan." });
            AllahIsimleri.Add(new string[] { "Metin", "54.png", "Çok sağlam olan." });
            AllahIsimleri.Add(new string[] { "Veliyy", "55.png", "İyi kullarına, gerçek mü’minlere dost olan." });
            AllahIsimleri.Add(new string[] { "Hamid", "56.png", "Her türlü hamd ve övgüye layık olan." });
            AllahIsimleri.Add(new string[] { "Muhsi", "57.png", "İstisnasız her şeyin tek tek sayısını bilen." });
            AllahIsimleri.Add(new string[] { "Mubdi", "58.png", "Bütün mahlukatı maddesiz ve örneksiz olarak ilk baştan yaratan." });
            AllahIsimleri.Add(new string[] { "Muid", "59.png", "Yaratılmışları yok ettikten sonra tekrar yaratan." });
            AllahIsimleri.Add(new string[] { "Muhyi", "60.png", "İhya eden, dirilten, can bağışlayan, sağlık veren." });
            AllahIsimleri.Add(new string[] { "Mumit", "61.png", "Ölümü yaratan, öldüren." });
            AllahIsimleri.Add(new string[] { "Hayy", "62.png", "Diri, tam ve mükemmel manasıyla hayat sahibi." });
            AllahIsimleri.Add(new string[] { "Kayyum", "63.png", "Gökleri, yeri ve her şeyi tutan." });
            AllahIsimleri.Add(new string[] { "Vacid", "64.png", "İstediğini, istediği vakit bulan." });
            AllahIsimleri.Add(new string[] { "Macid", "65.png", "Kadri büyük, keremi bol olan." });
            AllahIsimleri.Add(new string[] { "Vahid", "66.png", "Tek olan." });
            AllahIsimleri.Add(new string[] { "Samed", "67.png", "Sığınacak tek dayanak olan." });
            AllahIsimleri.Add(new string[] { "Kadir", "68.png", "Her şeye gücü yeten, her istediğini yapmaya kâdir olan." });
            AllahIsimleri.Add(new string[] { "Muktedir", "69.png", "Kuvvet ve kudret sahipleri üzerinde dilediği gibi tasarruf eden." });
            AllahIsimleri.Add(new string[] { "Mukaddim", "70.png", "İstediğini ileri geçirip, öne alan." });
            AllahIsimleri.Add(new string[] { "Muahhir", "71.png", "İstediğini geri koyan, arkaya bırakan." });
            AllahIsimleri.Add(new string[] { "Evvel", "72.png", "Başlangıcı olmayan, ilk olan." });
            AllahIsimleri.Add(new string[] { "Ahir", "73.png", "Bitişi olmayan, son olan." });
            AllahIsimleri.Add(new string[] { "Zahir", "74.png", "Açıkca bilinen, âşikâr olan." });
            AllahIsimleri.Add(new string[] { "Batın", "75.png", "Gizli olan." });
            AllahIsimleri.Add(new string[] { "Vali", "76.png", "Her şeyi tek başına idare eden." });
            AllahIsimleri.Add(new string[] { "Muteali", "77.png", "Aklın mümkün gördüğü her şeyden, her hâl ve tavırdan münezzeh olan." });
            AllahIsimleri.Add(new string[] { "Berr", "78.png", "Kullarına iyilik ve ihsanı, nimetleri bol olan." });
            AllahIsimleri.Add(new string[] { "Tevvab", "79.png", "Tövbeleri kabul eden." });
            AllahIsimleri.Add(new string[] { "Muntakim", "80.png", "Suçluları adaletiyle cezalandırıp intikam alan." });
            AllahIsimleri.Add(new string[] { "Afuvv", "81.png", "Affı ve rahmeti çok olan, bağışlayan." });
            AllahIsimleri.Add(new string[] { "Rauf", "82.png", "Pek acıyan, lütuf ve merhametle pek esirgeyen." });
            AllahIsimleri.Add(new string[] { "MalikülMülk", "83.png", "Mülkün ebedi sahibi olan." });
            AllahIsimleri.Add(new string[] { "ZulCelalivelİkram", "84.png", "Her türlü büyüklüğün, her türlü keremin sahibi olan." });
            AllahIsimleri.Add(new string[] { "Muksıt", "85.png", "Bütün işleri birbirine uygun ve denk yapan." });
            AllahIsimleri.Add(new string[] { "Cami", "86.png", "İstediğini istediği zaman istediği yerde toplayan." });
            AllahIsimleri.Add(new string[] { "Ganiyy", "87.png", "Çok zengin olan." });
            AllahIsimleri.Add(new string[] { "Muğni", "88.png", "İstediğini zengin eden." });
            AllahIsimleri.Add(new string[] { "Mani", "89.png", "Bazı şeylerin meydana gelmesine müsaade etmeyen, engelleyen. " });
            AllahIsimleri.Add(new string[] { "Dar", "90.png", "Elem ve zarar verecek şeyleri yaratan, hüsrana ugratan." });
            AllahIsimleri.Add(new string[] { "Nafi", "91.png", "Hayır ve menfaat verecek şeyleri yaratan." });
            AllahIsimleri.Add(new string[] { "Nur", "92.png", "Alemleri nurlandıran." });
            AllahIsimleri.Add(new string[] { "Hadi", "93.png", "Hidayete ve doğru yola erdiren." });
            AllahIsimleri.Add(new string[] { "Bedi", "94.png", "Örneksiz, misilsiz, hayret verici nice âlemler icad eden." });
            AllahIsimleri.Add(new string[] { "Baki", "95.png", "Varlığının sonu bulunmayan, ebedi olan." });
            AllahIsimleri.Add(new string[] { "Varis", "96.png", "Servetlerin gerçek sahibi olan." });
            AllahIsimleri.Add(new string[] { "Reşid", "97.png", "Bütün işleri ezeli takdirine uygun bir nizam ve hikmet üzere sonuna ulaştıran." });
            AllahIsimleri.Add(new string[] { "Sabur", "98.png", "Çok sabırlı olan." });

            KuranSureler.Add(1, "Fatiha");
            KuranSureler.Add(2, "Bakara");
            KuranSureler.Add(3, "Âli İmran");
            KuranSureler.Add(4, "Nisa");
            KuranSureler.Add(5, "Maide");
            KuranSureler.Add(6, "En'Am");
            KuranSureler.Add(7, "Araf");
            KuranSureler.Add(8, "Enfal");
            KuranSureler.Add(9, "Tevbe");
            KuranSureler.Add(10, "Yunus");
            KuranSureler.Add(11, "Hud");
            KuranSureler.Add(12, "Yusuf");
            KuranSureler.Add(13, "Rad");
            KuranSureler.Add(14, "İbrahim");
            KuranSureler.Add(15, "Hicr");
            KuranSureler.Add(16, "Nahl");
            KuranSureler.Add(17, "İsra");
            KuranSureler.Add(18, "Kehf");
            KuranSureler.Add(19, "Meryem");
            KuranSureler.Add(20, "TaHa");
            KuranSureler.Add(21, "Enbiya");
            KuranSureler.Add(22, "Hac");
            KuranSureler.Add(23, "Müminin");
            KuranSureler.Add(24, "Nur");
            KuranSureler.Add(25, "Furkan");
            KuranSureler.Add(26, "Şuara");
            KuranSureler.Add(27, "Neml");
            KuranSureler.Add(28, "Kasas");
            KuranSureler.Add(29, "Ankebut");
            KuranSureler.Add(30, "Rum");
            KuranSureler.Add(31, "Lokman");
            KuranSureler.Add(32, "Secde");
            KuranSureler.Add(33, "Ahzap");
            KuranSureler.Add(34, "Sebe");
            KuranSureler.Add(35, "Fatır");
            KuranSureler.Add(36, "Yasin");
            KuranSureler.Add(37, "Saiat");
            KuranSureler.Add(38, "Sad");
            KuranSureler.Add(39, "Zümer");
            KuranSureler.Add(40, "Mümin");
            KuranSureler.Add(41, "Fussilet");
            KuranSureler.Add(42, "Şura");
            KuranSureler.Add(43, "Zühruf");
            KuranSureler.Add(44, "Dühan");
            KuranSureler.Add(45, "Casiye");
            KuranSureler.Add(46, "Ahkaf");
            KuranSureler.Add(47, "Muhammed");
            KuranSureler.Add(48, "Fetih");
            KuranSureler.Add(49, "Hucurat");
            KuranSureler.Add(50, "Kaf");
            KuranSureler.Add(51, "Zariyat");
            KuranSureler.Add(52, "Tur");
            KuranSureler.Add(53, "Necm");
            KuranSureler.Add(54, "Kamer");
            KuranSureler.Add(55, "Rahman");
            KuranSureler.Add(56, "Vakıa");
            KuranSureler.Add(57, "Hadid");
            KuranSureler.Add(58, "Mücadile");
            KuranSureler.Add(59, "Haşr");
            KuranSureler.Add(60, "Mümtehime");
            KuranSureler.Add(61, "Sai");
            KuranSureler.Add(62, "Cumua");
            KuranSureler.Add(63, "Münafıkın");
            KuranSureler.Add(64, "Teğabün");
            KuranSureler.Add(65, "Talak");
            KuranSureler.Add(66, "Tahrim");
            KuranSureler.Add(67, "Mülk");
            KuranSureler.Add(68, "Kalem");
            KuranSureler.Add(69, "Hakka");
            KuranSureler.Add(70, "Mearic");
            KuranSureler.Add(71, "Nuh");
            KuranSureler.Add(72, "Cin");
            KuranSureler.Add(73, "Müzzemmil");
            KuranSureler.Add(74, "Müddenir");
            KuranSureler.Add(75, "Kıyamet");
            KuranSureler.Add(76, "İnsan");
            KuranSureler.Add(77, "Mürselat");
            KuranSureler.Add(78, "Nebe");
            KuranSureler.Add(79, "Naziat");
            KuranSureler.Add(80, "Abese");
            KuranSureler.Add(81, "Tekvir");
            KuranSureler.Add(82, "İnitar");
            KuranSureler.Add(83, "Mütaıin");
            KuranSureler.Add(84, "İnşikak");
            KuranSureler.Add(85, "Büruc");
            KuranSureler.Add(86, "Tarık");
            KuranSureler.Add(87, "A'la");
            KuranSureler.Add(88, "Gaşiye");
            KuranSureler.Add(89, "Fecr");
            KuranSureler.Add(90, "Beled");
            KuranSureler.Add(91, "Şems");
            KuranSureler.Add(92, "Leyl");
            KuranSureler.Add(93, "Duha");
            KuranSureler.Add(94, "İnşirah");
            KuranSureler.Add(95, "Tın");
            KuranSureler.Add(96, "Alak");
            KuranSureler.Add(97, "Kadir");
            KuranSureler.Add(98, "Beyine");
            KuranSureler.Add(99, "Zizal");
            KuranSureler.Add(100, "Adiyat");
            KuranSureler.Add(101, "Karia");
            KuranSureler.Add(102, "Tekasür");
            KuranSureler.Add(103, "Asr");
            KuranSureler.Add(104, "Hüzeme");
            KuranSureler.Add(105, "Fil");
            KuranSureler.Add(106, "Kureyş");
            KuranSureler.Add(107, "Maun");
            KuranSureler.Add(108, "Kevser");
            KuranSureler.Add(109, "Kairun");
            KuranSureler.Add(110, "Nasr");
            KuranSureler.Add(111, "Tebbet");
            KuranSureler.Add(112, "İhlas");
            KuranSureler.Add(113, "Felak");
            KuranSureler.Add(114, "Nas");

            KuranSureTurkceIsimleri.Add("Fatiha", "Açılış");
            KuranSureTurkceIsimleri.Add("Bakara", "Sığır");
            KuranSureTurkceIsimleri.Add("Ali İmran", "İmran Ailesi");
            KuranSureTurkceIsimleri.Add("Nisa", "Kadın");
            KuranSureTurkceIsimleri.Add("Maide", "Sofra");
            KuranSureTurkceIsimleri.Add("En'Am", "Davar");
            KuranSureTurkceIsimleri.Add("Araf", "OrtaYer");
            KuranSureTurkceIsimleri.Add("Enfal", "Ganimetler");
            KuranSureTurkceIsimleri.Add("Tevbe", "Tövbe");
            KuranSureTurkceIsimleri.Add("Yunus", "Yunus");
            KuranSureTurkceIsimleri.Add("Hud", "Hud");
            KuranSureTurkceIsimleri.Add("Yusuf", "Yusuf");
            KuranSureTurkceIsimleri.Add("Rad", "GökGürültüsü");
            KuranSureTurkceIsimleri.Add("İbrahim", "İbrahim");
            KuranSureTurkceIsimleri.Add("Hicr", "Hicr");
            KuranSureTurkceIsimleri.Add("Nahl", "Bal Arısı");
            KuranSureTurkceIsimleri.Add("İsra", "Gece Yürüyüşü");
            KuranSureTurkceIsimleri.Add("Kehf", "Mağara");
            KuranSureTurkceIsimleri.Add("Meryem", "Meryem");
            KuranSureTurkceIsimleri.Add("TaHa", "TaHa");
            KuranSureTurkceIsimleri.Add("Enbiya", "Peygamber");
            KuranSureTurkceIsimleri.Add("Hac", "Hac");
            KuranSureTurkceIsimleri.Add("Müminin", "İnananlar");
            KuranSureTurkceIsimleri.Add("Nur", "Işık");
            KuranSureTurkceIsimleri.Add("Furkan", "İyi yi Kötü yü Ayıran");
            KuranSureTurkceIsimleri.Add("Şuara", "Şairler");
            KuranSureTurkceIsimleri.Add("Neml", "Karınca");
            KuranSureTurkceIsimleri.Add("Kasas", "Tarihi Olaylar");
            KuranSureTurkceIsimleri.Add("Ankebut", "Dişi Örümcek");
            KuranSureTurkceIsimleri.Add("Rum", "Romalılar");
            KuranSureTurkceIsimleri.Add("Lokman", "Lokman");
            KuranSureTurkceIsimleri.Add("Secde", "Secde");
            KuranSureTurkceIsimleri.Add("Ahzap", "Karşıtlar");
            KuranSureTurkceIsimleri.Add("Sebe", "Sebe");
            KuranSureTurkceIsimleri.Add("Fatır", "Yaratan");
            KuranSureTurkceIsimleri.Add("Yasin", "Yasin");
            KuranSureTurkceIsimleri.Add("Saiat", "Dizinler");
            KuranSureTurkceIsimleri.Add("Sad", "Sad");
            KuranSureTurkceIsimleri.Add("Zümer", "Topluluklar");
            KuranSureTurkceIsimleri.Add("Mümin", "İnanan");
            KuranSureTurkceIsimleri.Add("Fussilet", "Açıklanmış");
            KuranSureTurkceIsimleri.Add("Şura", "Danışma");
            KuranSureTurkceIsimleri.Add("Zühruf", "Gösteriş");
            KuranSureTurkceIsimleri.Add("Dühan", "Duman");
            KuranSureTurkceIsimleri.Add("Casiye", "Diz Çöküş");
            KuranSureTurkceIsimleri.Add("Ahkaf", "Kum Tepeleri");
            KuranSureTurkceIsimleri.Add("Muhammed", "Muhammed");
            KuranSureTurkceIsimleri.Add("Fetih", "Fethetmek");
            KuranSureTurkceIsimleri.Add("Hucurat", "Odalar");
            KuranSureTurkceIsimleri.Add("Kaf", "Kaf");
            KuranSureTurkceIsimleri.Add("Zariyat", "Rüzgarlar");
            KuranSureTurkceIsimleri.Add("Tur", "Sina Dağı");
            KuranSureTurkceIsimleri.Add("Necm", "Yıldız");
            KuranSureTurkceIsimleri.Add("Kamer", "Ay");
            KuranSureTurkceIsimleri.Add("Rahman", "Merhametli");
            KuranSureTurkceIsimleri.Add("Vakıa", "Olay");
            KuranSureTurkceIsimleri.Add("Hadid", "Demir");
            KuranSureTurkceIsimleri.Add("Mücadile", "Tartışma");
            KuranSureTurkceIsimleri.Add("Haşr", "Yığınak");
            KuranSureTurkceIsimleri.Add("Mümtehime", "Sorgulanan");
            KuranSureTurkceIsimleri.Add("Sai", "Saf Tutma");
            KuranSureTurkceIsimleri.Add("Cumua", "Cuma(Toplanma)");
            KuranSureTurkceIsimleri.Add("Münafıkın", "İkiyüzlüler");
            KuranSureTurkceIsimleri.Add("Teğabün", "Aldanış");
            KuranSureTurkceIsimleri.Add("Talak", "Boşanma");
            KuranSureTurkceIsimleri.Add("Tahrim", "Yasaklama");
            KuranSureTurkceIsimleri.Add("Mülk", "Yönetim");
            KuranSureTurkceIsimleri.Add("Kalem", "Kalem");
            KuranSureTurkceIsimleri.Add("Hakka", "Gerçekleşen");
            KuranSureTurkceIsimleri.Add("Mearic", "Yükseliş Yolları");
            KuranSureTurkceIsimleri.Add("Nuh", "Nuh");
            KuranSureTurkceIsimleri.Add("Cin", "Cin");
            KuranSureTurkceIsimleri.Add("Müzzemmil", "Bürnen");
            KuranSureTurkceIsimleri.Add("Müddenir", "Gizlenen");
            KuranSureTurkceIsimleri.Add("Kıyamet", "Diriliş");
            KuranSureTurkceIsimleri.Add("İnsan", "İnsan");
            KuranSureTurkceIsimleri.Add("Mürselat", "Gönderilenler");
            KuranSureTurkceIsimleri.Add("Nebe", "Haber");
            KuranSureTurkceIsimleri.Add("Naziat", "Söküp Çıkaranlar");
            KuranSureTurkceIsimleri.Add("Abese", "Surat Asma");
            KuranSureTurkceIsimleri.Add("Tekvir", "Dolama");
            KuranSureTurkceIsimleri.Add("İnitar", "Yarılma");
            KuranSureTurkceIsimleri.Add("Mütaıin", "Kandırılanlar");
            KuranSureTurkceIsimleri.Add("İnşikak", "Parçalanma");
            KuranSureTurkceIsimleri.Add("Büruc", "Burçlar");
            KuranSureTurkceIsimleri.Add("Tarık", "Delip Geçen");
            KuranSureTurkceIsimleri.Add("A'la", "Yüce");
            KuranSureTurkceIsimleri.Add("Gaşiye", "Kuşatan");
            KuranSureTurkceIsimleri.Add("Fecr", "Tan Vakti");
            KuranSureTurkceIsimleri.Add("Beled", "Şehir");
            KuranSureTurkceIsimleri.Add("Şems", "Güneş");
            KuranSureTurkceIsimleri.Add("Leyl", "Gece");
            KuranSureTurkceIsimleri.Add("Duha", "Kuşluk Vakti");
            KuranSureTurkceIsimleri.Add("İnşirah", "Ferahlık");
            KuranSureTurkceIsimleri.Add("Tın", "İncir");
            KuranSureTurkceIsimleri.Add("Alak", "Asılıp Tutunan");
            KuranSureTurkceIsimleri.Add("Kadir", "Kudret");
            KuranSureTurkceIsimleri.Add("Beyine", "Kanıt");
            KuranSureTurkceIsimleri.Add("Zizal", "Deprem");
            KuranSureTurkceIsimleri.Add("Adiyat", "Nefes Nefese Anlatanlar");
            KuranSureTurkceIsimleri.Add("Karia", "Şiddetli Sel");
            KuranSureTurkceIsimleri.Add("Tekasür", "Çokluk Yarışı");
            KuranSureTurkceIsimleri.Add("Asr", "Zaman");
            KuranSureTurkceIsimleri.Add("Hüzeme", "Dedikoducu");
            KuranSureTurkceIsimleri.Add("Fil", "Fil");
            KuranSureTurkceIsimleri.Add("Kureyş", "Kureyş Toplumu");
            KuranSureTurkceIsimleri.Add("Maun", "Yardımlaşma");
            KuranSureTurkceIsimleri.Add("Kevser", "Bolca Güzellik");
            KuranSureTurkceIsimleri.Add("Kairun", "İnkarcılar");
            KuranSureTurkceIsimleri.Add("Nasr", "Yardım");
            KuranSureTurkceIsimleri.Add("Tebbet", "Diken");
            KuranSureTurkceIsimleri.Add("İhlas", "Allah'ın Birliği");
            KuranSureTurkceIsimleri.Add("Felak", "Yararak Çıkarmak");
            KuranSureTurkceIsimleri.Add("Nas", "İnsanlar");
        }
        public int GetEbcedValue(char chr)
        {
            int result = 0;
            if (Ekarakterler.Count > 0)
            {

                try
                {
                    result = Ekarakterler[chr];
                }
                catch
                {
                    result = -2;
                }
            }
            else
            {
                result = -1;
            }
            return result;
        }
        public int SumStringEbced(string input)
        {
            int result = 0;
            if (Ekarakterler.Count > 0)
            {
                for (int i = 0; i < input.Length; i++)
                {
                    result += GetEbcedValue(input.ToUpper()[i]);
                }
                if (result < 0)
                {
                    result = -2;
                }
            }
            else
            {
                result = -1;
            }
            
            return result;
        }
        public int EvradEskat(string input)
        {
            int result = 0;
            if (Ekarakterler.Count > 0)
            {
                result = (SumStringEbced(input) / input.Length);
            }
            else
            {
                result = -1;
            }
            return result;
        }
        public int FindAnyNumberStrange(string input,string input2)
        {
            int result = 0;
            if (Ekarakterler.Count > 0)
            {
                result = ((((SumStringEbced(input) * Convert.ToInt32(input2)) / input.Length) - Convert.ToInt32(input2)) / input.Length) / SumStringEbced(input);
            }
            else
            {
                result = -1;
            }
            return result;
        }
        public List<double> GetEbcedToCharactersSome(int input)
        {
            List<double> result = new List<double>();
            result.Add((Math.Sqrt((double)input)));
            result.Add(Math.Round(Math.Sqrt((double)input)));
            return result;
        }
        public int GetManyNameEbcedSum(List<string> input)
        {
            int result = 0;
            if (Ekarakterler.Count > 0)
            {
                foreach (string name in input)
                {
                    result += SumStringEbced(name);
                }
            }
            else
            {
                result = -1;
            }
            return result;
        }
        public List<int> GiveMeAyatMyName(string input)
        {
            List<int> result = new List<int>();
            if (Ekarakterler.Count > 0)
            {
                int sum1 = GetEbcedValue(input.ToUpper()[0]) + GetEbcedValue(input.ToUpper()[input.Length - 1]);
                try
                {
                    result.Add(sum1);
                    result.Add(((AYAT) / sum1));
                    result.Add(((SURE) / sum1));
                }
                catch {
                    result.Add(1);
                }
            }
            return result;
        }
        public List<string[]> EsmaAlGenis(string input)
        {
            List<string[]> result = new List<string[]>();
            int myEbced = SumStringEbced(input);
            foreach (string[] AllahAdlari in AllahIsimleri)
            {
                int GuzelIsim = SumStringEbced(AllahAdlari[0].ToString());
                int different = Math.Max(myEbced, GuzelIsim) - Math.Min(myEbced, GuzelIsim);
                if (myEbced == GuzelIsim)
                {
                    result.Add(AllahAdlari);
                }
                else if (different == 2 || different == 3 || different == 1)
                {
                    result.Add(AllahAdlari);
                }
            }
            return result;
        }
        public List<string[]> EsmaAlNormal(string input)
        {
            List<string[]> result = new List<string[]>();
            int myEbced = SumStringEbced(input);
            foreach (string[] AllahAdlari in AllahIsimleri)
            {
                int GuzelIsim = SumStringEbced(AllahAdlari[0].ToString());
                if (myEbced == GuzelIsim)
                {
                    result.Add(AllahAdlari);
                }
            }
            return result;
        }
        public Bitmap EsmaYaGoreVefk7(string[] SecilenEsma)
        {
            Bitmap bmpVefk = new Bitmap(600, 600);
            if (AllahIsimleri.Count > 0)
            {
                Graphics gs = Graphics.FromImage(bmpVefk);
                gs.FillRectangle(Brushes.White, new Rectangle(0, 0, 600, 400));

                gs.DrawImage(new Bitmap(Image.FromFile("isimlerPNG/" + SecilenEsma[1]), new Size(150, 100)), new Point(200, 0));

                gs.DrawRectangle(new Pen(Brushes.Black, 2), new Rectangle(50, 100, 150, 100));
                gs.DrawImage(new Bitmap(Image.FromFile("isimlerPNG/" + SecilenEsma[1]), new Size(150, 100)), new Point(50, 100));
                gs.DrawRectangle(new Pen(Brushes.Black, 2), new Rectangle(200, 100, 150, 100));
                gs.DrawImage(new Bitmap(Image.FromFile("isimlerPNG/" + SecilenEsma[1]), new Size(150, 100)), new Point(200, 100));
                gs.DrawRectangle(new Pen(Brushes.Black, 2), new Rectangle(350, 100, 150, 100));
                gs.DrawImage(new Bitmap(Image.FromFile("isimlerPNG/" + SecilenEsma[1]), new Size(150, 100)), new Point(350, 100));

                gs.DrawRectangle(new Pen(Brushes.Black, 2), new Rectangle(50, 200, 150, 100));
                gs.DrawImage(new Bitmap(Image.FromFile("isimlerPNG/" + SecilenEsma[1]), new Size(150, 100)), new Point(50, 200));
                gs.DrawRectangle(new Pen(Brushes.Black, 2), new Rectangle(200, 200, 150, 100));
                gs.DrawImage(new Bitmap(Image.FromFile("isimlerPNG/" + SecilenEsma[1]), new Size(150, 100)), new Point(200, 200));
                gs.DrawRectangle(new Pen(Brushes.Black, 2), new Rectangle(350, 200, 150, 100));
                gs.DrawImage(new Bitmap(Image.FromFile("isimlerPNG/" + SecilenEsma[1]), new Size(150, 100)), new Point(350, 200));
            }
                return bmpVefk;
        }
    }
}
