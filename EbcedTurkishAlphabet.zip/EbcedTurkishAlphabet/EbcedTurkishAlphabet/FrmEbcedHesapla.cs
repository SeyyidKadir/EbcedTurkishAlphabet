﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EbcedTurkishAlphabet
{
    public partial class FrmEbcedHesapla : Form
    {
        public FrmEbcedHesapla()
        {
            InitializeComponent();
        }
        EbcedAlphabetsTurkish eat = new EbcedAlphabetsTurkish();
        private void FrmEbcedHesapla_Load(object sender, EventArgs e)
        {
            eat.Init();
        }

        private void btnHesapla_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtYazi.Text))
            {
                int sonuc = eat.SumStringEbced(txtYazi.Text);
                if (sonuc > 0)
                {
                    txtSonuc.Text = sonuc.ToString();
                }
                else
                {
                    txtSonuc.Text = "Doğru veri girilmedi mübarek :)";
                }
            }
            else
            {
                txtSonuc.Text = "Mübarek Boş Geçme :)";
            }
        }
    }
}
